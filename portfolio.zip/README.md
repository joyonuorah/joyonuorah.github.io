# Joy Onuorah — Portfolio / System Edition

A responsive, multilingual static website presenting Joy’s work across brand strategy, copywriting, communications, content marketing and journalism as one connected practice.

## Pages

- `index.html` — professional positioning and the integrated practice
- `system.html` — seven roles, what each means, success criteria and business value
- `library.html` — curated work in eight categories
- `about.html` — biography, portrait and opportunity-fit principles
- `contact.html` — email, WhatsApp and LinkedIn
- `cv.html` — recruiter-friendly experience timeline and printable CV
- Project and sample pages — Nigeria Everywhere, Kari Water, FutureTech Media, PharmaRun, Loopify 360, Baki Beauty, Centi and selected copywriting work
- `fr/` and `es/` — French and Spanish versions of the main pages

The interview with Nahi and Maya Halabi is included in **Interviews & human stories** in all three language libraries. The article is credited to Joy Onuorah by Nigeria Everywhere.

## Responsive design

The layout includes desktop, tablet and mobile breakpoints, a collapsible mobile navigation, flexible project grids, and touch-friendly controls. The main stylesheet includes responsive rules at 1170px, 920px and 650px, with additional responsive rules for project and copy pages.

## Accessibility

The multicolour accessibility control provides text resizing, high contrast, dark background, a simpler typeface, underlined links, extra line spacing, reduced motion and optional browser text-to-speech. Preferences stay in the visitor’s browser and can be reset. Keyboard navigation, skip links, semantic headings, visible focus indicators and descriptive portrait text are included. The site has not undergone a formal WCAG audit; browser text-to-speech is not a replacement for a screen reader.

## Deploy from an iPhone using GitHub

The easiest phone workflow is included in the separate **GitHub Deploy Kit**. It uses one upload (the complete website ZIP) and one GitHub Actions workflow to unpack and publish the multi-page site. This preserves clean page URLs, images, translations, the CV and all site assets.

1. Create a **public** GitHub repository named `joy-onuorah-portfolio` (public repositories can use GitHub Pages on GitHub Free).
2. Upload the website ZIP from the kit to the repository root and name it `portfolio.zip`.
3. In the repository, create `.github/workflows/deploy.yml` and paste the workflow supplied in the kit.
4. In **Settings → Pages**, set **Source** to **GitHub Actions**.
5. The workflow unpacks `portfolio.zip` and publishes the complete website. The live address will be `https://YOUR-GITHUB-USERNAME.github.io/joy-onuorah-portfolio/`.

To update the site later, replace `portfolio.zip` with the new version and commit the change. GitHub Actions will publish the update automatically.

**Important:** GitHub Pages is public-facing. Do not publish confidential client material or draft work without permission. The website includes selected samples and excerpts; confirm applicable client permissions before making it public.

## Alternative hosting

Netlify can also deploy the extracted website folder directly, or connect to a GitHub repository and automatically redeploy when the repository changes. Lovable is not required to host this static site.
