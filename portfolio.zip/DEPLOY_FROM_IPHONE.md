# Deploy Joy’s portfolio from an iPhone

Use the **GitHub Deploy Kit** supplied with this website. It contains the complete site ZIP and the workflow that publishes it.

1. In Safari, sign in to GitHub and create a **public** repository named `joy-onuorah-portfolio`.
2. Upload the website ZIP from the kit to the repository root. Name the uploaded file `portfolio.zip`.
3. On the repository page, choose **Add file → Create new file**.
4. In the filename field, enter `.github/workflows/deploy.yml`.
5. Open `deploy.yml` from the kit, copy its contents, paste them into GitHub’s editor, and commit the new file to `main`.
6. Open **Settings → Pages** and set the source to **GitHub Actions**.
7. Open the **Actions** tab and wait for “Deploy portfolio to GitHub Pages” to finish. Your site URL will be `https://YOUR-GITHUB-USERNAME.github.io/joy-onuorah-portfolio/`.

If GitHub Pages is set to GitHub Actions before the workflow is committed, the deployment starts automatically when the workflow file is added. If it does not, open the workflow in Actions and select **Run workflow**.

To update the portfolio, replace `portfolio.zip` in the repository with a newly supplied version and commit the change.

GitHub Pages is public-facing. Publish only material you have permission to share.
